﻿using System.Windows;

namespace XanWeather.Views;

public partial class MainView : Window
{
    public MainView()
    {
        InitializeComponent();
    }
}