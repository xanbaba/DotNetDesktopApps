﻿using System.Windows.Controls;

namespace XanWeather.Views;

public partial class WeatherLocationsView : UserControl
{
    public WeatherLocationsView()
    {
        InitializeComponent();
    }
}