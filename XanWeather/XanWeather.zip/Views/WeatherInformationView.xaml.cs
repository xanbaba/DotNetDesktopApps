﻿using System.Windows.Controls;

namespace XanWeather.Views;

public partial class WeatherInformationView : UserControl
{
    public WeatherInformationView()
    {
        InitializeComponent();
    }
}