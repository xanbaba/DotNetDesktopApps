﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace XanWeather.ViewModels;

public abstract class BaseViewModel : ObservableObject;