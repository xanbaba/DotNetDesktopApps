﻿namespace FastTyper;

public class Words
{
    public required List<string> Easy { get; init; }
    public required List<string> Medium { get; init; }
    public required List<string> Hard { get; init; }
}