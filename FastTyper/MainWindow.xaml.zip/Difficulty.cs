﻿namespace FastTyper;

public enum Difficulty
{
    Easy,
    Medium,
    Hard
}